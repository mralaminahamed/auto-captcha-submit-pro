export class PasswordCrawler {
    public url: any;

    constructor(url: string) {
        if (url) {
            this.url = url;
        } else {
            console.error('Crawling error. URL empty.')
        }
    }

    init(callBack?: any) {
        if (this.url) {
            console.log(this.url);
            this.track();
        }

        if (callBack) {
            callBack()
        }
    }

    private track() {
        ["click", "mouseover", "contextmenu"].forEach(function (event) {
            document.addEventListener(event, function () {
                let elementId: string[]  = [];
                document.querySelectorAll('form')?.forEach(function (element) {
                    if (element.nodeName === 'FORM') {
                        /*console.log(element);*/
                        PasswordCrawler.crawl(elementId, element);
                    }
                })
            })
        })
    }

    private static crawl(elementId: any, element: HTMLElement) {
        element.childNodes?.forEach(function (element) {
            if ((element as HTMLElement).nodeName === 'INPUT' || (element as HTMLElement).nodeName === 'BUTTON') {
                if ((element as HTMLElement).id != undefined || (element as HTMLElement).id !== "") {
                    elementId.push((element as HTMLElement).id);
                    /*console.log((element as HTMLElement).id)
                    console.log(elementId)*/
                    /*if (elementId !== undefined || elementId !== []){
                        elementId.forEach(function (id:string) {
                            console.log(id)
                            console.log((element as HTMLElement).id)
                            if (id && id !== (element as HTMLElement).id ){
                                elementId.push((element as HTMLElement).id);
                            }
                        })
                    }*/
                }
                /*console.log(element);*/
                if ((element as HTMLElement).nodeName === 'INPUT' && (element as HTMLButtonElement).type === 'submit' || (element as HTMLButtonElement).type === 'button' || (element as HTMLElement).nodeName === 'BUTTON' && (element as HTMLButtonElement).type === 'submit' || (element as HTMLButtonElement).type === 'button') {
                    element.addEventListener('click', function () {
                        if (elementId.length !== 0) {
                            for(let Id in elementId) {
                                if (document.querySelector('#' + elementId[Id])){
                                    console.log(document.querySelector('#' + elementId[Id]));  // output: Apple Orange Banana
                                }
                            }
                        }
                        /*console.log(elementId);
                        console.log(elementId);*/
                    });
                }
            } else {
                PasswordCrawler.crawl(elementId, (element as HTMLElement));
            }
        })
    }
}