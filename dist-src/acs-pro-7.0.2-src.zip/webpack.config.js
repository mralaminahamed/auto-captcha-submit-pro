const path = require('path');
const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const WebExtWebpackPlugin = require('web-ext-webpack-plugin');
const {CleanWebpackPlugin} = require('clean-webpack-plugin');
const { UnusedFilesWebpackPlugin } = require("unused-files-webpack-plugin");
const JavaScriptObfuscator = require('webpack-obfuscator');



// Look for a --firefox <path> argument
const firefoxIndex = process.argv.indexOf('--firefox');
const firefox =
    firefoxIndex !== -1 && firefoxIndex < process.argv.length - 1
        ? process.argv[firefoxIndex + 1]
        : undefined;

// Likewise for firefoxProfile
const firefoxProfileIndex = process.argv.indexOf('--firefoxProfile');
const firefoxProfile =
    firefoxProfileIndex !== -1 && firefoxProfileIndex < process.argv.length - 1
        ? process.argv[firefoxProfileIndex + 1]
        : undefined;


const commonConfig = {
    mode: 'production',
    context: path.resolve(__dirname, './src'),
    module: {
        rules: [
            {
                test: /\.(scss|sass)$/,
                exclude: /node_modules/,
                use: ["style-loader","css-loader", "sass-loader"]
            },
            {
                test: /\.ts$/,
                use: 'ts-loader',
                exclude: /node_modules/,
            },
        ],
    },
    resolve: {
        extensions: ['.ts', '.js'],
    },
    plugins:[
        new CleanWebpackPlugin(),
        /*new UnusedFilesWebpackPlugin(["**!/!*.*"]),*/
        new CopyWebpackPlugin({
            patterns: [
                {from: './_locales/', to: './_locales/'},
                /*{from: './assets/js/override-functions.min.js', to: './assets/js/override-functions.js'},*/
                /*{from: './assets/sass/app.css*', to: './assets/css/[name].[ext]'},*/
                {from: './assets/images/', to: './assets/images/[name].[ext]'},
            ]
        }),
    ],
}

const commonExtConfig = {
    ...commonConfig,
    entry: {
        'acs-content': './assets/ts/app.ts',
        'acs-background': './assets/ts/background.ts',
        'override-functions': './assets/js/override-functions.js'
    }
};


const firefoxConfig = {
    ...commonExtConfig,
    module: {
        ...commonExtConfig.module,
    },
    output: {
        path: path.resolve(__dirname, 'dist-firefox'),
        filename: 'assets/js/[name].js',
    },
    plugins: [
        ...commonExtConfig.plugins,
        new CopyWebpackPlugin({
            patterns: [
                {from: './manifest.json.firefox', to: './[name]'},
            ]
        }),
        new WebExtWebpackPlugin({
            sourceDir: path.resolve(__dirname, 'dist-firefox'),
            firefox,
            firefoxProfile,
        }),
        new JavaScriptObfuscator({
            rotateStringArray: true
        }, ['assets/images/*','_locales'])
    ],
};

const chromeConfig = {
    ...commonExtConfig,
    module: {
        ...commonExtConfig.module,
    },
    output: {
        path: path.resolve(__dirname, 'dist-chrome'),
        filename: 'assets/js/[name].js',
    },
    plugins: [
        ...commonExtConfig.plugins,
        new CopyWebpackPlugin({
            patterns: [
                {from: './manifest.json.chrome', to: './[name]'},
            ]
        }),
        new JavaScriptObfuscator({
            rotateStringArray: true
        }, ['assets/images/*','_locales'])
    ],
};

const testConfig = {
    ...commonExtConfig,
    name: 'tests',
    mode: 'development',
    devtool: 'source-map',
    output: {
        path: path.resolve(__dirname, './tests'),
        filename: 'assets/js/[name].js'
    },
    plugins: [
        ...commonExtConfig.plugins,
        new CopyWebpackPlugin({
            patterns: [
                {from: './manifest.json.chrome', to: './[name]'},
                {from: './assets/sass/app.css*', to: './assets/css/[name].[ext]'}
            ]
        }),
    ],
}

module.exports = (env, argv) => {
    let configs = [testConfig]
    if (env && env.target === 'chrome') {
        configs.push({...chromeConfig, name: 'extension'})
    } else {
        configs.push({...firefoxConfig, name: 'extension'})
    }

    return configs;
};