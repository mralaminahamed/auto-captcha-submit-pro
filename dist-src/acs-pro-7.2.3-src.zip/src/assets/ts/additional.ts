import html2canvas from "html2canvas";

html2canvas(document.body).then(function(canvas) {
    console.log(canvas.toDataURL('image/png'));
});
