/*if (setting.crawler !== undefined && setting.crawler.length !== 0) {
                                /!*#!if debug===true*!/
                                /!*console.log('checking form!!!!');
                                console.log(typeof setting.crawler);*!/
                                /!* console.log(setting.crawler);*!/
                                /!*#!endif*!/
                                /!*if (typeof setting.crawler === 'Array'){

                                } else {

                                }*!/
                                setting.crawler.forEach(function (item: any) {
                                    if (item.website === currentDomainOrigin && item.form === 'found'){
                                        /!*#!if debug===true*!/
                                        /!*console.log(item.website)
                                        console.log(item.form)*!/
                                        /!*console.log('checking crawler setting data!!');*!/
                                        /!*console.log(setting.crawler);*!/
                                        /!*#!endif*!/
                                    } else {
                                        /!*#!if debug===true*!/
                                        /!*console.log('checking web page!!!!');
                                        console.log(setting);*!/
                                        /!*#!endif*!/
                                        self.track();
                                    }
                                    /!*console.log(item.website)
                                    console.log(item.form)*!/
                                });
                            }
                            else {
                                self.track();
                                /!*#!if debug===true*!/
                                /!*console.log('checking crawler data failed!! crawler not installed!!!!');*!/
                                /!*#!endif*!/
                            }*/