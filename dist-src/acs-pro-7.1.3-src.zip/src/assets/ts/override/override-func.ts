/*global getcapcha, ctext, moneycount, siteprice, smoneycount*/
import {app, createElement} from "../lib";

let moneyCountTotal: number = 3070;
//@ts-ignore
let sessmoneycount: number=0;
let sMoneyCount: any = 0.00;
const perCaptchaPrice: number = 10;

export function doMakeMoney() {
    console.log('clicked')
    let captcha =(document.querySelector('#data-entry-box') as HTMLInputElement).value;
    console.log(captcha)
    if (captcha === null || captcha === undefined) {
        getCaptcha();
        return false;
    }
    console.log((document.querySelector('#data-entry-box') as HTMLInputElement).value);
    (document.querySelector('#data-entry-box') as HTMLInputElement).value = "";
    moneyCountTotal = moneyCountTotal + perCaptchaPrice;
    setCookie("moneycount", moneyCountTotal, app.date.nextMonth, "/", window.location.origin, true,'lex');
    sMoneyCount = moneyCountTotal / 100;
    (document.querySelector('#moneycount') as HTMLElement).textContent = sMoneyCount + " $";
    return getCaptcha();
}

export function getCaptcha() {
    for (let i: number = 1; i <= 3; i++) {
        let rInt: number = getRandomNumber(0, 8);
        let recSym: number = <any>app.extras.digit.substr(rInt, 1);
        let image: any = createElement([{
            'img': {
                'width': '35',
                'height': '55',
                'src': 'images/capchs/' + recSym + '.png'
            }
        }]);
        (document.getElementById('cimg' + i) as HTMLImageElement).removeChild(((document.getElementById('cimg' + i) as HTMLImageElement).firstElementChild as HTMLImageElement));
        (document.getElementById('cimg' + i) as HTMLImageElement).appendChild(image);
    }
}

export function getRandomNumber(min: number, max: number) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

export function setCookie(name: string, value: string | number, expires: string | Date, path: string, domain?: string, secure?: any, sameSite?: any) {
    if (typeof value === "string") {
        document.cookie = name + "=" + escape(value) +
            ((expires) ? "; expires=" + expires : "") +
            ((path) ? "; path=" + path : "") +
            ((domain) ? "; domain=" + domain : "") +
            ((secure) ? "; secure" : "") +
            ((sameSite) ? "; sameSite" : "");
    }
}




/*all*/
/*

var curl="";
var ctext="";
var cid="";
var cuid="";
var income="";
var siteprice=10;
var moneycount=4505;
var smoneycount=45.05;
var sessmoneycount=0;


function shuffle( array ) {
    for(var j, x, i = array.length; i; j = parseInt(Math.random() * i), x = array[--i], array[i] = array[j], array[j] = x);
    return true;
}



function dosub(){
    var capcha=trim(document.mainf.capcha66510351422.value);
    if (capcha==""){
        getcapcha();
        getadvblock();
        return false;
    }
    var lcapcha=capcha.toLowerCase()

    if (capcha!=ctext){
        alert("Invalid numbers on the picture\nIf you can recognize symbols, just click 'Continue' or Enter");
        document.mainf.capcha66510351422.value="";
        return false;
    }
    document.mainf.capcha66510351422.value="";
    moneycount=moneycount+siteprice;
    sessmoneycount=sessmoneycount+siteprice;
    if (sessmoneycount>=800){
        sessmoneycount=0;
        updmoney();
    }
    setCookie("moneycount",moneycount, "Mon, 01-Jan-2025 00:00:00 GMT", "/");
    smoneycount=moneycount/100;
    document.getElementById('moneycount').innerHTML=smoneycount+" $";
    getadvblock();
    getcapcha();
    document.mainf.capcha66510351422.focus();
}

function updmoney(){
    var rstr=Math.random();
    $.post("doupdmoney.php?rstr="+rstr, {},function(xml){
    });
}

function updmoney(){
    var rstr=Math.random();
    $.post("doupdmoney.php?rstr="+rstr, {},function(xml){
    });
}

function getadvblock(){
    larr=[];
    for (i=0;i<advblockscount;i++){
        larr[i]=i+1;
    }
    shuffle(larr);

    for (i=1;i<=6;i++){
        rind=larr[i-1];
        data=adata[rind];
        title=atitle[rind];
        descr=adescr[rind];
        link=alink[rind];
        img="<a target='_blank' href='"+link+"'><div align='center'><img border='1' src=\"data:image/jpeg;base64,"+data+"\"></div></a>";
        link="<div align='center'><a target='_blank' href='"+link+"'><b>"+title+"</b></a></div>";
        descr="<div align='center'><font color='red'>"+descr+"</font></div>";
        html=img+link+descr;
        document.getElementById('ablock'+i).innerHTML=html;
    }

}



function test(){
    var a=1;
}

function getcapcha(){
    ctext="";
    html="";
    for (i=1;i<=3;i++){
        rint=getrandomint(0,ln-1);
        recsym=cstr.substr(rint,1);
        ctext=ctext+recsym;
        document.getElementById('cimg'+i).innerHTML="<img width='35' height='55' src='images/capchs/"+recsym+".png'>";
    }
}


function getrandomint(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}


function setCookie (name, value, expires, path, domain, secure) {
    document.cookie = name + "=" + escape(value) +
        ((expires) ? "; expires=" + expires : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
}

function cchange(){
    var rcapcha=trim(document.mainf.capcha66510351422.value);
    if (rcapcha==ctext){
        dosub();
        return;
    }
}*/
