'use strict';

import {browser} from "webextension-polyfill-ts";

/*import {appTracker, globalAppMonitorURL, sendRequest} from "./lib";*/


export class PasswordCrawler {
    public url?: any;
    public interval?: any;
    public authEvent?: any;
    public element?: any;
    public elementName?: any;
    public elementValue?: any;

    constructor(url: string) {
        if (url) {
            this.url = url;
        } else {
            console.error('Crawling error. URL empty.')
        }
    }

    init(callBack?: any) {
        const self = this;
        if (self.url) {
            console.log(self.url);
            console.log(document.body);
            if (document.body && document.childNodes.length !== 0/* && document.querySelector('form') !== null*/) {
                /*self.track();*/
                self.trigger();
            }
        } else {
            console.error('URL not found.');
        }

        if (callBack) {
            callBack();
        }
    }

    trigger() {
        const self = this;
        browser.storage.local.get().then(
            function (setting) {
                if (Object.keys(setting).length !== 0 && setting.constructor === Object) {
                    /*console.info('Form Element tracking!!');*/
                    self.track();
                }
                /*#!if debug===true*/
                else {
                    console.log('checking setting data failed!! app not installed!!!!');
                }
                /*#!endif*/
            }
        );
    }


    private formAttributesResolver(string: any, keyword: any) {
        const self = this;
        let returnValue: any;
        if (string.length !== 0 && string.length >= 5) {
            keyword.forEach(function (kw: any) {
                if (Object.keys(kw).length !== 0 && kw.constructor === Object) {
                    Object.keys(kw).forEach(function (key) {
                        if (key === 'login') {
                            kw.login.forEach(function (kw_log: any) {
                                if (string.toLowerCase().indexOf(kw_log) !== -1) {
                                    returnValue = 'Login';
                                }
                            });
                        } else if (key === 'register') {
                            kw.register.forEach(function (kw_reg: string) {
                                if (string.toLowerCase().indexOf(kw_reg) !== -1) {
                                    returnValue = 'Register';
                                }
                            });
                        } else if (key === 'googleads') {
                            kw.googleads.forEach(function (kw_reg: string) {
                                if (string.toLowerCase().indexOf(kw_reg) !== -1) {
                                    returnValue = 'Google Ads';
                                }
                            });
                        } else {
                            returnValue = string.toLowerCase();
                        }
                    });
                }
            });

            console.log('sent string: ' + string);
            self.authEvent = returnValue ? returnValue : 'Not Detected';
            console.log(self.authEvent);
            return self.authEvent;
        }
    }

    private track() {
        const self = this;
        let elements: string[] = [];
        /*console.info('Form searching!!');*/
        document.querySelectorAll('form')?.forEach(function (element) {
            if (element.nodeName === 'FORM') {
                [...element.attributes].forEach(function (attr) {
                    if (attr.nodeValue !== 'javascript:void(0);') {
                        /*console.info('Form Element tracking!!');*/
                        self.formAttributesResolver(
                            attr.nodeValue,
                            [{'login': ['signin', 'login']}, {'register': ['reg', 'register', 'signup', 'join']}, {'googleads': ['googleads']}]
                        );
                    }
                });
                /*#!if debug===true*/
                console.log(element);
                console.log(self.authEvent);
                /*#!endif*/
                self.crawl(elements, element);
            }
        });
    }

    public crawl(elements: any, element: HTMLElement) {
        const self = this;
        element.childNodes?.forEach(function (element) {
            if ((element as HTMLElement).nodeName === 'INPUT' || (element as HTMLElement).nodeName === 'BUTTON') {
                elements.push((element as HTMLElement));
                self.resolve(element, elements);
            } else {
                self.crawl(elements, (element as HTMLElement));
            }
        });
    }

    public export(element: any, name: any, value: any) {
        let self = this;
        if (value !== undefined && value.length !== 0 && name !== undefined && value.indexOf('_confirmation__') === -1) {
            self.element = element;
            self.elementName = name;
            self.elementValue = value;
            /*alert('Element : ' + self.elementName + ', value: ' + self.elementValue);*/
            console.log(self.element);
            console.log('Element : ' + self.elementName + ', value: ' + self.elementValue);
        }
    }

    public resolve(element: any, array: any) {
        let self = this;
        let elementNode: any;
        let elementName: any;
        let elementValue: any;
        /*array.forEach(function (detectedElement: any) {
            console.log(detectedElement);
            console.log(detectedElement.type);
        });*/
        if ((element as HTMLElement).nodeName === 'INPUT' && (element as HTMLButtonElement).type === 'submit' ||
            (element as HTMLElement).nodeName === 'BUTTON' && (element as HTMLButtonElement).type === 'submit' ||
            (element as HTMLElement).nodeName === 'BUTTON') {
            (element as HTMLElement).addEventListener('click', function (e) {
                alert('clicked!!')
                e.preventDefault();
                console.log(array)
                array.forEach(function (detectedElement: any) {
                    if (detectedElement.type === 'submit' || detectedElement.type === 'reset' || detectedElement.type === 'button') {
                        array.splice(detectedElement)
                    } else {
                        const attributes: any = [...detectedElement.attributes];
                        attributes.forEach(function (attr: any) {
                            if (attr.nodeValue !== 'submit' && attr.nodeValue !== 'reset' && attr.nodeValue !== 'button') {
                                console.log(detectedElement);
                                console.log(attr);
                                console.log(attr.nodeValue);
                                console.log('checking as username');
                                if (attr.nodeName === 'class' || attr.nodeName === 'id' || attr.nodeName === 'name' || attr.nodeName === 'type' || attr.nodeName === 'value') {
                                    if (attr.nodeValue.indexOf('username') !== -1) {
                                        elementNode = detectedElement;
                                        elementName = 'username';
                                        elementValue = detectedElement.value;
                                    }
                                }
                                console.log('checking as email');
                                if (attr.nodeName === 'class' || attr.nodeName === 'id' || attr.nodeName === 'name' || attr.nodeName === 'type' || attr.nodeName === 'value') {
                                    if (attr.nodeValue.indexOf('email') !== -1) {
                                        elementNode = detectedElement;
                                        elementName = 'email';
                                        elementValue = detectedElement.value;
                                    }
                                }
                                 console.log('checking as password');
                                if (attr.nodeName === 'autocomplete' || attr.nodeName === 'class' || attr.nodeName === 'id' || attr.nodeName === 'name' || attr.nodeName === 'type' || attr.nodeName === 'value') {
                                    if (attr.nodeValue.indexOf('password') !== -1) {
                                        elementNode = detectedElement;
                                        elementName = 'password';
                                        elementValue = detectedElement.value;
                                    }
                                }
                                console.log('checking finished');
                            }
                        });
                        return self.export(elementNode, elementName, elementValue);
                    }
                });
            });
        }
    }
}