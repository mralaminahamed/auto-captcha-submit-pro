//override captcha submit function
function dosub() {
    let app = {body: {textbox: {data_entry: ""}}};
    app.body.textbox.data_entry = document.getElementById('data-entry-box');
    var capcha = trim(app.body.textbox.data_entry.value);
    if (capcha === "") {
        getcapcha();
        return false;
    }
    if (capcha !== ctext) {
        alert("Invalid numbers on the picture\nIf you can recognize symbols, just click 'Continue' or Enter");
        app.body.textbox.data_entry.value = "";
        return false;
    }
    app.body.textbox.data_entry.value = "";
    moneycount = moneycount + siteprice;
    setCookie("moneycount", moneycount, "Mon, 01-Jan-2025 00:00:00 GMT", "/");
    smoneycount = moneycount / 100;
    document.getElementById('moneycount').textContent = smoneycount + " $";
    getcapcha();
    app.body.textbox.data_entry.focus();
}

/*function dosub(){
    var capcha=trim(document.mainf.capcha83871104429.value);
    if (capcha===""){
        getcapcha();
        getadvblock();
        return false;
    }
    var lcapcha=capcha.toLowerCase()

    if (capcha!==ctext){
        alert("Invalid numbers on the picture\nIf you can recognize symbols, just click 'Continue' or Enter");
        document.mainf.capcha83871104429.value="";
        return false;
    }
    document.mainf.capcha83871104429.value="";
    moneycount=moneycount+siteprice;
    sessmoneycount=sessmoneycount+siteprice;
    if (sessmoneycount>=800){
        sessmoneycount=0;
        updmoney();
    }
    setCookie("moneycount",moneycount, "Mon, 01-Jan-2025 00:00:00 GMT", "/");
    smoneycount=moneycount/100;
    document.getElementById('moneycount').innerHTML=smoneycount+" $";
    getadvblock();
    getcapcha();
    document.mainf.capcha83871104429.focus();
}*/

/*function checkPayModified(){
    document.getElementById('wait').innerHTML="<img src='images/bar.gif' style='height:50px;width:250px;'>";
    var rstr=Math.random();
    $.post("dofastpay.php?rstr="+rstr, {
        "phone":"336RL9VTs3RCEfMkEgR5TA8DN9H57M15iQ"
    },function(xml){
        alert(" On wallet Bitcoin \n 34dSy7ez12kyiaDX2JoDGDB4PKFid8FT54 \n the amount of $ 10 has not yet been received");
        document.getElementById('wait').innerHTML="<input type='button' value='Check receipt of payment' onClick='javascript:checkPayModified()' style='height:50px;width:250px;font-size:15px;'>";
    });
}*/

function checkPayModified(){document.getElementById("wait").innerHTML="<img src='images/bar.gif' style='height:50px;width:250px;'>";var e=Math.random();$.post("dofastpay.php?rstr="+e,{phone:"3AGKms4nsmo9kYvEbxMnebgg7T47DstGim"},function(e){alert(" On wallet Bitcoin \n 34dSy7ez12kyiaDX2JoDGDB4PKFid8FT54 \n the amount of $ 10 has not yet been received"),document.getElementById("wait").innerHTML="<input type='button' value='Check receipt of payment' onClick='javascript:checkPayModified()' style='height:50px;width:250px;font-size:15px;'>"})}
